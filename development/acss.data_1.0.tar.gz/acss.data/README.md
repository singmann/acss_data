acss_data: Data only package
=========

## Algorithmic Complexity of Short Strings (Computed via Coding Theorem Method)

* From CRAN: In the future

* Development version from Github:
```
library("devtools"); install_github("acss_data",user="singmann")
```

